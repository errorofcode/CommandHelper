import turtle
import os
import random
import time
coloraura = random.randint(0,9)
colorfill = random.randint(0,10)
a = ["red", "orange", "gold", "yellow", "green", "cyan", "blue", "purple", "violet", "white", "gray"]
af = ["red", "orange", "gold", "yellow", "green", "cyan", "blue", "purple", "violet", "white"]

coloraura = af[coloraura]
colorfill = a[colorfill]
os.chdir("Game_appdata")

start = ((-9, 0), (0, 9), (9, 0), (0, -9))
shearsp1 = ((0, -2), (1, -2), (1, -3), (2, -3), (3, -3), (3, -2), (4, -2), (4, -1), (4, 0), (3, 0), (3, 1), (4, 1), (4, 2), (4, 3), (3, 3), (3, 4), (2, 4), (1, 4), (1, 3), (0, 3), (0, 4), (-1, 4), (-2, 4), (-2, 3), (-3, 3), (-3, 2), (-3, 1), (-2, 1), (-2, 0), (-3, 0), (-3, -1), (-3, -2), (-2, -2), (-2, -3), (-1, -3), (0, -3), (0, -2), (0, -3), (-1, -3), (-1, -10), (-1, -3), (-3, -3), (-3, -10), (-3, -3), (-10, -10), (-3, -3), (-10, -3), (-3, -3), (-3, -1), (-10, -1), (-3, -1), (-3, 2), (-10, 2), (-3, 2), (-3, 4), (-10, 4), (-3, 4), (-10, 10), (-3, 4), (-3, 10), (-3, 4), (-1, 4), (-1, 10), (-1, 4), (2, 4), (2, 10), (2, 4), (4, 4), (10, 4), (4, 4), (10, 10), (4, 4), (4, 10), (4, 4), (4, 2), (10, 2), (4, 2), (4, -1), (10, -1), (4, -1), (4, -3), (10, -3), (4, -3), (4, -10), (4, -3), (10, -10), (4, -3), (0, -3))
shearsactive1 = ((-10, -10), (10, -10), (10, -8), (-10, -8))
shearsactive2 = ((-10, -10), (10, -10), (10, -4), (-10, -4))
shearssh1 = ((1, 1), (10, 1), (10, 10), (10, -5), (10, 10), (10, 1), (1, 1), (1, 0), (1, 10), (-10, 10), (5, 10), (-10, 10), (1, 10), (1, 0), (0, 0), (-10, 0), (-10, -10), (-10, 5), (-10, -10), (-10, 0), (0, 0), (0, 1), (0, -10), (10, -10), (-5, -10), (10, -10), (0, -10), (0, 1))
cub = ((10, 10), (-10, 10), (-10, -10), (10, -10), (10, 10))
badcub = ((10, 10), (4, 10), (4, 0), (-1, 0), (-1, 10), (-3, 10),(-3, 8),(-8, 8),(-8, 10),(-10, 10), (-10, -10), (10, -10), (10, 10))
arrowing = ((-5, -5), (0, 5), (1, 5), (5, -5), (-5, -5))
aarrowing = ((-5, 5), (0, -5), (1, -5), (5, 5), (-5, 5))
turtle.register_shape('start', start)
turtle.register_shape('shears', shearsp1)
turtle.register_shape('shearsactive1', shearsactive1)
turtle.register_shape('shearsactive2', shearsactive2)
turtle.register_shape('shears1', shearssh1)
turtle.register_shape('cub', cub)
turtle.register_shape("badcub", cub)
turtle.register_shape('arrowing', arrowing)
turtle.register_shape('aarrowing', aarrowing)

window = turtle.Screen()
player = turtle.Turtle()
turtle.ht()
turtle.tracer(0, 0)
turtle.color(colorfill)
turtle.color("blue")
playerstats = {"x": 0, "y": 0, "dx": 9, "dy": 9, "speed": 0, "tx": 0, "ty": 0}
player.speed(0)
player.color("blue")

window.title("New Game")
player.up()
end=turtle.Turtle()
end.up()
turtle.register_shape("end.gif")
turtle.register_shape("air.gif")
end.color("purple", "red")
end.shape("end.gif")
objects = []
ids = []
id_num = 0
moving = {"x": 0, "y": 0}
player_pos = []
godmodes = False
if godmodes == True:
    teleport = True
    antimove = True
    spectator = True
    godmode = True
    console = True
else:
    teleport = False
    antimove = False
    spectator = False
    godmode = False
    console = True
#fishs = open("Puffer.png", "r")
turtle.register_shape("fish.gif")
turtle.register_shape("fish1.gif")
turtle.register_shape("bat.gif")
turtle.register_shape("shears.gif")
turtle.register_shape("gun.gif")
turtle.register_shape("gunleft.gif")
turtle.register_shape("gunup.gif")
turtle.register_shape("gundown.gif")
turtle.register_shape("shearsmoved.gif")
turtle.register_shape("shearsmovedpart.gif")
turtle.register_shape("shearsmovedpart1.gif")
turtle.register_shape("shearsmovedpartright.gif")
turtle.register_shape("shearsmovedpartleft.gif")
turtle.register_shape("shearsmovedpartdown.gif")
turtle.register_shape("shearsmovedpart1right.gif")
turtle.register_shape("shearsmovedpart1left.gif")
turtle.register_shape("shearsmovedpart1down.gif")
turtle.register_shape("chainsaw.gif")
turtle.register_shape("player.gif")
turtle.register_shape("player_god.gif")
turtle.register_shape("wall.gif")
turtle.screensize(500, 500)
balance = open("balance.txt", "a", encoding="utf-8")
balanceread = open("balance.txt", "r", encoding="utf-8")
    
mcbalance = balanceread.read()
nums = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
mbalance = "9"
cnt0 = 0
for i in range(len(mcbalance)):
    if mcbalance[i] in nums:
        cnt0 += 1
if cnt0 == 0:
    balance.write("0")
for i in range(len(mcbalance)):
    if mcbalance[i] in nums:
        mbalance = mbalance + mcbalance[i]
mbalance = int(mbalance)
mbalance = int(mbalance) - 9 * (10 ** (cnt0))
if godmodes == False:
    player.shape("player.gif")
else:
    player.shape("player_god.gif")
player.shape()
sizemap = 1
def create_object(x, y, type, direction, range, time, bad):
    global objects
    global ids
    global id_num
    objects.append({"block": True, "activied": False, "teleported": False, "tx": x, "ty": y, "x": x, "y": y, "dx": 0, "dy": 0, "direction": direction, "range": range, "rangedir": "", "rangeset": 0, "type": type, "id": str(id_num) + " " + type, "turtle": "", "turtlepart": "", "rotated": False, "time": time, "bad": bad})
    ids.append(str(id_num) + " " + type)
    id_num += 1
def bats():
    global objects
    global ids
    global id_num
    n=0
    for i in objects:
        if objects[n]["type"] == "bat":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["turtle"].up()
                objects[n]["activied"] = True
                objects[n]["block"] = False
                objects[n]["bad"] = True
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("bat.gif")
                objects[n]["turtle"].color("blue", "blue")
                objects[n]["teleported"] = True
            if objects[n]["direction"] == "left" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(180)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "up" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(270)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "right" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(0)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "down" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(90)
                objects[n]["rotated"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            if objects[n]["rangeset"] < objects[n]["range"]:
                objects[n]["rangedir"] = True
            if objects[n]["rangeset"] >= objects[n]["range"]:
                objects[n]["rangedir"] = False
            if objects[n]["rangedir"] == False:
                objects[n]["turtle"].rt(180)
                objects[n]["time"] += 1
                objects[n]["rangedir"] = True
                objects[n]["rangeset"] = 0
            if objects[n]["rangedir"] == True:
                objects[n]["turtle"].fd(0.58)
                objects[n]["rangeset"] += 1
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 5
            objects[n]["dy"] = 5
        n+=1
def shearsmoved():
    global objects
    global ids
    global id_num
    n=0
    for i in objects:
        if objects[n]["type"] == "shearsmoved":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["turtle"].up()
                objects[n]["activied"] = False
                objects[n]["block"] = False
                objects[n]["bad"] = True
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("shearsmovedpart.gif")
                objects[n]["turtle"].color("red")
                objects[n]["teleported"] = True
            if objects[n]["direction"] == "left" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(180)
                objects[n]["turtle"].shape("shearsmovedpartleft.gif")
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "up" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(270)
                objects[n]["rotated"] = True
                objects[n]["turtle"].shape("shearsmovedpart.gif")
            elif objects[n]["direction"] == "right" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(0)
                objects[n]["turtle"].shape("shearsmovedpartright.gif")
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "down" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(90)
                objects[n]["turtle"].shape("shearsmovedpartdown.gif")
                objects[n]["rotated"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            if objects[n]["rangedir"] == True:
                objects[n]["range"] += 1
            
            if objects[n]["range"] >= 58:
                objects[n]["activied"] = True
                objects[n]["rangeset"] += 1
            if objects[n]["range"] == 58:
                if objects[n]["direction"] == "up":
                    objects[n]["turtle"].shape("shearsmovedpart1.gif")
                if objects[n]["direction"] == "right":
                    objects[n]["turtle"].shape("shearsmovedpart1right.gif")
                if objects[n]["direction"] == "left":
                    objects[n]["turtle"].shape("shearsmovedpart1left.gif")
                if objects[n]["direction"] == "down":
                    objects[n]["turtle"].shape("shearsmovedpart1down.gif")
                objects[n]["turtle"].color("blue")
            if objects[n]["rangeset"] >= 116:
                objects[n]["range"] = 0
                if objects[n]["direction"] == "up":
                    objects[n]["turtle"].shape("shearsmovedpart.gif")
                if objects[n]["direction"] == "right":
                    objects[n]["turtle"].shape("shearsmovedpartright.gif")
                if objects[n]["direction"] == "left":
                    objects[n]["turtle"].shape("shearsmovedpartleft.gif")
                if objects[n]["direction"] == "down":
                    objects[n]["turtle"].shape("shearsmovedpartdown.gif")
                
                objects[n]["turtle"].color("red")
                objects[n]["rangeset"] = 0
                objects[n]["activied"] = False
                objects[n]["rangedir"] = False
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 0
            objects[n]["dy"] = 0
        n+=1
def shears():
    global objects
    global ids
    global id_num
    n=0
    for i in objects:
        if objects[n]["type"] == "shears":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["turtle"].up()
                objects[n]["activied"] = True
                objects[n]["block"] = False
                objects[n]["bad"] = True
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("shears.gif")
                objects[n]["turtle"].color("blue","blue")
                objects[n]["teleported"] = True
            if objects[n]["direction"] == "left" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(180)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "up" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(270)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "right" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(0)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "down" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(90)
                objects[n]["rotated"] = True
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9
            objects[n]["dy"] = 9
        n+=1
def blaster():
    global objects
    global ids
    global id_num
    n=0
    for i in objects:
        if objects[n]["type"] == "blaster":
            if objects[n]["turtle"] == "":
                create_object(objects[n]["x"], objects[n]["y"], "blockblaster", objects[n]["direction"], 500, 0, False)
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["turtle"].up()
                objects[n]["turtlepart"] = turtle.Turtle()
                objects[n]["turtlepart"].up()
                objects[n]["turtlepart"].shape("arrowing")
                objects[n]["block"] = False
                objects[n]["activied"] = True
                objects[n]["bad"] = True
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("gun.gif")
                objects[n]["turtle"].color("blue", "red")
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtlepart"].color("blue", "blue")
                objects[n]["teleported"] = True
            if objects[n]["direction"] == "left" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(180)
                objects[n]["turtlepart"].rt(180)
                objects[n]["rotated"] = True
                objects[n]["turtle"].shape("gunleft.gif")
            elif objects[n]["direction"] == "up" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(270)
                objects[n]["turtle"].shape("gunup.gif")
                objects[n]["turtlepart"].rt(270)
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "right" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(0)
                objects[n]["turtlepart"].rt(0)
                objects[n]["turtle"].shape("gun.gif")
                objects[n]["rotated"] = True
            elif objects[n]["direction"] == "down" and objects[n]["rotated"] == False:
                objects[n]["turtle"].rt(90)
                objects[n]["turtlepart"].rt(90)
                objects[n]["turtle"].shape("gundown.gif")
                objects[n]["rotated"] = True
            objects[n]["turtlepart"].speed(objects[n]["time"])
            objects[n]["rangeset"] += 1
            if objects[n]["rangeset"] >= 116:
                objects[n]["turtlepart"].fd(10)
                objects[n]["rangeset"] += 1
            if objects[n]["rangeset"] >= objects[n]["range"] / 25 + 2000 / 25:
                objects[n]["turtlepart"].goto(objects[n]["x"], objects[n]["y"])
                objects[n]["rangeset"] = 0
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtlepart"].pos()
            objects[n]["dx"] = 5
            objects[n]["dy"] = 5
        n+=1
def fish():
    global objects
    global ids
    global id_num
    n = 0
    for i in objects:
        if objects[n]["type"] == "fish":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = True
                objects[n]["turtle"].up()
                objects[n]["dx"] = 9
                objects[n]["dy"] = 9
                objects[n]["bad"] = True
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("fish.gif")
                objects[n]["turtle"].color("blue", "red")
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["rangeset"] += 1
            if objects[n]["rangeset"] >= 232:
                objects[n]["turtle"].shape("fish1.gif")
                objects[n]["turtle"].color("blue", "blue")
                objects[n]["block"] = False
                objects[n]["dx"] = 29
                objects[n]["dy"] = 29
                objects[n]["activied"] = True
            if objects[n]["rangeset"] >= 348:
                objects[n]["turtle"].shape("fish.gif")
                objects[n]["activied"] = False
                objects[n]["block"] = True
                objects[n]["turtle"].color("blue", "red")
                
                objects[n]["rangeset"] = 0
                objects[n]["dx"] = 9
                objects[n]["dy"] = 9
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
        n += 1
def chainsaw():
    global objects
    global ids
    global id_num
    global player_pos
    n=0
    for i in objects:
        if objects[n]["type"] == "chainsaw":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = False
                objects[n]["turtle"].up()
                objects[n]["dx"] = 9
                objects[n]["dy"] = 9
                objects[n]["bad"] = True
                objects[n]["activied"] = True
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("chainsaw.gif")
                objects[n]["turtle"].color("blue", "blue")
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["rangeset"] += 1
            if objects[n]["rangeset"] >= objects[n]["range"]:
                objects[n]["turtle"].goto(player_pos[0]["x"], player_pos[0]["y"])
                player_pos.remove(player_pos[0])
                objects[n]["rangeset"] = objects[n]["range"] - 1
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            
            
        n+=1

def block():
    global objects
    global ids
    global id_num
    global coloraura
    n=0
    for i in objects:
        if objects[n]["type"] == "block":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = True
                objects[n]["turtle"].up()
                objects[n]["activied"] = False
                objects[n]["bad"] = False
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("wall.gif")
                objects[n]["turtle"].color("white")
                
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9
            objects[n]["dy"] = 9
        n+=1
def air():
    global objects
    global ids
    global id_num
    global coloraura
    n=0
    for i in objects:
        if objects[n]["type"] == "air":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = "money"
                objects[n]["turtle"].up()
                objects[n]["turtle"].color("gold")
                objects[n]["turtle"].shape("circle")
                objects[n]["turtle"].shapesize(0.1)
                objects[n]["activied"] = False
                objects[n]["bad"] = False
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9
            objects[n]["dy"] = 9
            
        n+=1
def moneyclaim():
    global objects
    global ids
    global id_num
    global coloraura
    n=0
    for i in objects:
        if objects[n]["type"] == "money":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = "money+"
                objects[n]["turtle"].up()
                objects[n]["turtle"].color("gold", "black")
                objects[n]["turtle"].shape("circle")
                objects[n]["turtle"].shapesize(0.3)
                objects[n]["activied"] = False
                objects[n]["bad"] = False
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9
            objects[n]["dy"] = 9
            
        n+=1
def star():
    global objects
    global ids
    global id_num
    global coloraura
    n=0
    for i in objects:
        if objects[n]["type"] == "star":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = "star"
                objects[n]["turtle"].up()
                objects[n]["turtle"].color("gold")
                objects[n]["turtle"].shape("triangle")
                objects[n]["turtle"].shapesize(0.7)
                objects[n]["activied"] = False
                objects[n]["bad"] = False
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].rt(-90)
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9
            objects[n]["dy"] = 9
            
        n+=1
starsmoven = 0
def stars():
    global objects
    global ids
    global id_num
    global coloraura
    global starsmoven
    global mbalance
    n=0
    cnt = 0
    for i in objects:
        if objects[n]["type"] == "star":
            cnt += 1
        n += 1
    n = 0
    for i in objects:
        if objects[n]["type"] == "star":
            if objects[n]["turtle"].isvisible():
                objects[n]["turtle"].st()
                objects[n]["turtle"].goto(((cnt * 25)* (-1)) + starsmoven + 95, 200)
                starsmoven += 25
                objects[n]["turtle"].color("gold", "black")
                objects[n]["turtle"].shapesize(1)
            else:
                objects[n]["turtle"].goto(((cnt * 25)* (-1)) + starsmoven + 95, 200)
                x1, x2 = objects[n]["turtle"].pos()
                starsmoven += 25
                objects[n]["turtle"].st()
                objects[n]["turtle"].color("gold")
                objects[n]["turtle"].shapesize(1)
                mbalance = int(mbalance) + 25
            
        n+=1
can_money = [25, 50, 100, 125, 225, 250]
can_moneyd = can_money[random.randint(0, 5)]
def moneys():
    global objects
    global ids
    global id_num
    global coloraura
    global moneysmoven
    global mbalance
    global can_moneyd
    n=0
    cnt = 0
    cnt1 = 0
    cnt2 = 0
    for i in objects:
        if objects[n]["type"] == "air":
            
            cnt += 1
        n += 1
    n = 0
    for i in objects:
        if objects[n]["type"] == "air":
            if objects[n]["turtle"].isvisible():
                cnt2 += 1
            else:
                
                cnt1 += 1
        n += 1
    if cnt > 0:
        turtle.goto(-450, 230)
        turtle.color("gold")
        for i in range(cnt1 * 100 // cnt):
            turtle.down()
            turtle.fd(10)
        turtle.color("red")
        x1, y1 = turtle.pos()
        while x1 < 550:

            turtle.down()
            turtle.fd(10)
            x1, y1 = turtle.pos()
        
                
            n+=1
    
        if cnt2 == 0:
            turtle.color("gold")
            mbalance = int(mbalance) + can_moneyd
            turtle.write(can_moneyd)
        else:
            turtle.color("red")
            turtle.write(can_moneyd)
moneysmoven = 0
def blockblaster():
    global objects
    global ids
    global id_num
    n=0
    for i in objects:
        if objects[n]["type"] == "blockblaster":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle() 
                objects[n]["block"] = True
                objects[n]["turtle"].up()
                objects[n]["activied"] = False
                objects[n]["bad"] = False
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                objects[n]["turtle"].shape("gun.gif")
                objects[n]["turtle"].ht()
                objects[n]["turtle"].color("blue", "red")
                objects[n]["teleported"] = True
            if objects[n]["direction"] == "up":
                objects[n]["turtle"].shape("gunup.gif")
            if objects[n]["direction"] == "right":
                objects[n]["turtle"].shape("gun.gif")
            if objects[n]["direction"] == "left":
                objects[n]["turtle"].shape("gunleft.gif")
            if objects[n]["direction"] == "down":
                objects[n]["turtle"].shape("gundown.gif")
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9

            objects[n]["dy"] = 9
        n+=1
def blockshearsmoved():
    global objects
    global ids
    global id_num
    n = 0
    for i in objects:
        if objects[n]["type"] == "blockshearsmoved":
            if objects[n]["turtle"] == "":
                objects[n]["turtle"] = turtle.Turtle()
                objects[n]["block"] = True
                objects[n]["turtle"].up()
                objects[n]["activied"] = False
                objects[n]["bad"] = False
                create_object(objects[n]["x"],objects[n]["y"] + 20, "shearsmoved", "up", 10, 10, True)
                create_object(objects[n]["x"],objects[n]["y"] - 20, "shearsmoved", "down", 10, 10, True)
                create_object(objects[n]["x"] - 20,objects[n]["y"], "shearsmoved", "left", 10, 10, True)
                create_object(objects[n]["x"] + 20,objects[n]["y"], "shearsmoved", "right", 10, 10, True)
            if objects[n]["teleported"] == False:
                objects[n]["turtle"].shape("shearsmoved.gif")
                objects[n]["turtle"].goto(objects[n]["x"],objects[n]["y"])
                
                objects[n]["turtle"].color("blue", "red")
                objects[n]["teleported"] = True
            objects[n]["turtle"].speed(objects[n]["time"])
            objects[n]["tx"], objects[n]["ty"] = objects[n]["turtle"].pos()
            objects[n]["dx"] = 9
            objects[n]["dy"] = 9
        n += 1
tick_pos = []
def player_movingright():
    global moves
    global objects
    global ids
    global id_num
    global antimove
    global moving
    global tick
    global tick_pos
    move = "right"
    if moves == "None":
        moves = move
        if move == "right":
            n = 0
            for i in objects:
                if moving == {"x": 0, "y": 0} and antimove == False:
                    moving = {"x": 1, "y": 0}
                    tick += 1
                    x1, y1 = player.position()
                    tick_pos.append({"x": x1, "y": y1})
                elif antimove == True:
                    moving = {"x": 1, "y": 0}
                n += 1
        moves = move
def player_movingleft():
    global moves
    global objects
    global ids
    global id_num
    global moving
    global antimove
    global tick
    global tick_pos
    move = "left"
    if moves == "None":
        moves = move
        if move == "left":
            n = 0
            for i in objects:
                
                if moving == {"x": 0, "y": 0} and antimove == False:
                    moving = {"x": -1, "y": 0}
                    tick += 1
                    x1, y1 = player.position()
                    tick_pos.append({"x": x1, "y": y1})
                elif antimove == True:
                    moving = {"x": -1, "y": 0}
                n += 1
        moves = move
def player_movingup():
    global moves
    global objects
    global ids
    global antimove
    global id_num
    global moving
    global tick
    global tick_pos
    move = "up"
    if moves == "None":
        moves = move
        if move == "up":
            n = 0
            for i in objects:
                if moving == {"x": 0, "y": 0} and antimove == False:
                    moving = {"x": 0, "y": 1}
                    tick += 1
                    x1, y1 = player.position()
                    tick_pos.append({"x": x1, "y": y1})
                elif antimove == True:
                    moving = {"x": 0, "y": 1}
                n += 1
                
        moves = move
ends = False
def testbad():
    global moves
    global objects
    global ids
    global id_num
    global moving
    global godmode
    global spectator
    global starsmoven
    global mbalance
    global shields
    global tick_pos
    global tick
    global playerstats
    global shieldcooldown
    global timestop
    global timestopcooldown
    global ends
    
    if shieldcooldown > 0:
        shieldcooldown -= 1
    if shieldcooldown == 0 and shields > 0:
        shields -= 3
        if shields > 0:
            shieldcooldown = 10000
    if timestopcooldown > 0:
        timestopcooldown -= 1
    if timestopcooldown == 0 and timestop > 0:
        timestop -= 1
        if timestop > 0:
            timestopcooldown = 10000
    if shields < 0:
        shields = 0
        shieldcooldown = 0
    if shields > 0:
        player.shape("player_god.gif")
    elif godmodes == True:
        player.shape("player_god.gif")
    else:
        player.shape("player.gif")
    if 0 == 0:
        if 0 == 0:
            n = 0
            for i in objects:
                playerstats["x"], playerstats["y"] = player.position()
                if playerstats["x"] + playerstats["dx"] >= objects[n]["tx"] - objects[n]["dx"] and playerstats["y"] + playerstats["dy"] >= objects[n]["ty"] - objects[n]["dy"] and playerstats["x"] - playerstats["dx"] <= objects[n]["tx"] + objects[n]["dx"] and playerstats["y"] - playerstats["dy"] <= objects[n]["ty"] + objects[n]["dy"]:
                    
                    if objects[n]["bad"] == True and objects[n]["activied"] == True and shields == 0:
                        if godmode == False and shields == 0:
                            ends = True
                            player.ht()
                            moving = {"x": 0, "y": 0}
                            turtle.up()
                            turtle.goto(0,150)
                            
                            turtle.color("orange")
                            turtle.write("GAME OVER", font=("Verdana",15, "normal"))
                            turtle.exitonclick()
                            window.mainloop()
                    elif objects[n]["bad"] == True and objects[n]["activied"] == True and shields > 0:
                        playerstats["x"], playerstats["y"] = player.position()
                        player.goto(playerstats["tx"], playerstats["ty"])
                        
                       
                        moving = {"x": 0, "y": 0}
                        shields -= 1
                    if objects[n]["bad"] == True and objects[n]["type"] == "shearsmoved":
                        objects[n]["rangedir"] = True
                        
                        
                if playerstats["x"] + playerstats["dx"] >= objects[n]["tx"] - objects[n]["dx"] and playerstats["y"] + playerstats["dy"] >= objects[n]["ty"] - objects[n]["dy"] and playerstats["x"] - playerstats["dx"] <= objects[n]["tx"] + objects[n]["dx"] and playerstats["y"] - playerstats["dy"] <= objects[n]["ty"] + objects[n]["dy"]:
                
                    if objects[n]["block"] == True and spectator == False:
                        playerstats["x"], playerstats["y"] = player.position()
                        if player.isvisible():
                            player.goto(playerstats["x"] - moving["x"]*2, playerstats["y"] - moving["y"]*2)
                            if tick > 0:
                                tick_pos.remove(tick_pos[-1])
                                tick -= 1
                        playerstats["x"], playerstats["y"] = player.position()
                       
                        moving = {"x": 0, "y": 0}
                        
                if playerstats["x"] + playerstats["dx"] >= objects[n]["tx"] - objects[n]["dx"] and playerstats["y"] + playerstats["dy"] >= objects[n]["ty"] - objects[n]["dy"] and playerstats["x"] - playerstats["dx"] <= objects[n]["tx"] + objects[n]["dx"] and playerstats["y"] - playerstats["dy"] <= objects[n]["ty"] + objects[n]["dy"]:
                
                    if objects[n]["block"] == "money":
                        objects[n]["turtle"].ht()
                    if objects[n]["block"] == "money+":
                        
                        if objects[n]["turtle"].isvisible() and player.isvisible():
                            mbalance = int(mbalance) + 25
                        objects[n]["turtle"].ht()
                if playerstats["x"] + playerstats["dx"] >= objects[n]["tx"] - objects[n]["dx"] and playerstats["y"] + playerstats["dy"] >= objects[n]["ty"] - objects[n]["dy"] and playerstats["x"] - playerstats["dx"] <= objects[n]["tx"] + objects[n]["dx"] and playerstats["y"] - playerstats["dy"] <= objects[n]["ty"] + objects[n]["dy"]:
                
                    if objects[n]["block"] == "star":
                        objects[n]["turtle"].ht()
                x1, y1 = end.position()
                if playerstats["x"] + playerstats["dx"] >= x1 - 9 and playerstats["y"] + playerstats["dy"] >= y1 - 9 and playerstats["x"] - playerstats["dx"] <= x1 + 9 and playerstats["y"] - playerstats["dy"] <= y1 + 9:
                        ends = True
                        balancewrite = open("balance.txt", "w", encoding="utf-8")
                        balancewrite.write(str(mbalance))
                        turtle.shape("air.gif")
                        turtle.up()
                        turtle.reset()
                        turtle.up()
                        turtle.shape("air.gif")
                        stars()
                        moneys()
                        turtle.up()
                        turtle.ht()
                        turtle.color("blue")
                        turtle.goto(-100, -120)
                        turtle.write(str(mbalance) + "$")
                        turtle.up()
                        moving = {"x": 0, "y": 0}
                        turtle.goto(10,150)
                        turtle.color("orange")
                        
                        turtle.write("YOU WIN", font=("Verdana",15, "normal"))
                        turtle.tracer(1, 1)
                        
                        turtle.exitonclick()
                        window.mainloop()
                        
                
                n += 1

tick = 0
def testtruebad():
    global objects
    global ids
    global id_num
    if 0 == 0:
        if 0 == 0:
            n = 0
            
            for i in objects:
                l = 0
                for i in objects:

                    if objects[l]["block"] == False:
                        if objects[n]["block"] == True and objects[n]["type"] != "blockblaster" and objects[l]["type"] != "blaster" and objects[l]["type"] != "fish" and objects[l]["type"] != "chainsaw":
                            if objects[l]["tx"] + objects[l]["dx"] >= objects[n]["tx"] - objects[n]["dx"] and objects[l]["ty"] + objects[l]["dy"] >= objects[n]["ty"] - objects[n]["dy"] and objects[l]["tx"] - objects[l]["dx"] <= objects[n]["tx"] + objects[n]["dx"] and objects[l]["ty"] - objects[l]["dy"] <= objects[n]["ty"] + objects[n]["dy"]:
                                objects[l]["rangeset"] = 0
                                objects[l]["turtle"].goto(objects[l]["x"], objects[l]["y"])
                                
                    if objects[l]["block"] == False:
                        x1, y1 = end.position()
                        if objects[l]["type"] != "blaster" and objects[l]["type"] != "fish":
                            if objects[l]["tx"] + objects[l]["dx"] >= x1 - 9 and objects[l]["ty"] + objects[l]["dy"] >= y1 - 9 and objects[l]["tx"] - objects[l]["dx"] <= x1 + 9 and objects[l]["ty"] - objects[l]["dy"] <= y1 + 9:
                                objects[l]["rangeset"] = 0
                                objects[l]["turtle"].goto(objects[l]["x"], objects[l]["y"])
                    if objects[l]["block"] == False:
                        if objects[n]["block"] == True and objects[n]["type"] != "blockblaster" and objects[l]["type"] == "blaster" and objects[l]["type"] != "fish":
                            if objects[l]["tx"] + objects[l]["dx"] >= objects[n]["tx"] - objects[n]["dx"] and objects[l]["ty"] + objects[l]["dy"] >= objects[n]["ty"] - objects[n]["dy"] and objects[l]["tx"] - objects[l]["dx"] <= objects[n]["tx"] + objects[n]["dx"] and objects[l]["ty"] - objects[l]["dy"] <= objects[n]["ty"] + objects[n]["dy"]:
                                objects[l]["rangeset"] = 0
                                objects[l]["turtlepart"].goto(objects[l]["x"], objects[l]["y"])
                                
                    if objects[l]["block"] == False:
                        x1, y1 = end.position()
                        if objects[n]["block"] == True and objects[n]["type"] != "blockblaster" and objects[l]["type"] == "blaster" and objects[l]["type"] != "fish":
                            if objects[l]["tx"] + objects[l]["dx"] >= x1 - 9 and objects[l]["ty"] + objects[l]["dy"] >= y1 - 9 and objects[l]["tx"] - objects[l]["dx"] <= x1 + 9 and objects[l]["ty"] - objects[l]["dy"] <= y1 + 9:
                                objects[l]["rangeset"] = 0
                                objects[l]["turtlepart"].goto(objects[l]["x"], objects[l]["y"])
                                
                            
                            
                            
                    l += 1
                n += 1
def stop():
    global moves
    global objects
    global ids
    global id_num
    global moving
    global antimove
    global tick
    
    if antimove == True:
        move = "None"
        if moves == "None":
            moves = move
            if move == "None":
                n = 0
                for i in objects:
                    moving = {"x": 0, "y": 0}
                    
                    n += 1
def player_movingdown():
    global moves
    global objects
    global ids
    global id_num
    global antimove
    global moving
    global tick
    global tick_pos
    move = "down"
    if moves == "None":
        moves = move
        if move == "down":
            n = 0
            for i in objects:
                if moving == {"x": 0, "y": 0} and antimove == False:
                    moving = {"x": 0, "y": -1}
                    tick += 1
                    x1, y1 = player.position()
                    tick_pos.append({"x": x1, "y": y1})
                elif antimove == True:
                    moving = {"x": 0, "y": -1}
                n += 1
moves = "None"


def godtp(x,y):
    global antimove
    global godmode
    global teleport
    global moving
    if teleport == True:
        if antimove == True:
            moving = {"x": 0, "y": 0}
        player.setpos(x, y)

window.onkey(player_movingright, "d")
window.listen()
window.onkey(player_movingleft, "a")
window.listen()
window.onkey(player_movingup, "w")
window.listen()
window.onkey(player_movingdown, "s")
window.listen()
window.onkey(stop, "space")
window.listen()
window.onclick(godtp, btn = 3)
window.listen()
mapmodes = [random.randint(1, 7)]
mapmodesx = random.randint(1, 10)
maps = []
if 0 == 0:
    if mapmodes[0] == 1:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "player"}, {"type": "money"}, {"type": "money"}, {"type": "money"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "block"}, {"type": "money"}, {"type": "star"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "money"}, {"type": "money+"}, {"type": "money"}, {"type": "money"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "money"}, {"type": "money"}, {"type": "money"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "star"}, {"type": "money"}, {"type": "bad", "nbt": ["chainsaw", "left", 500, 6, True]}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "block"}, {"type": "block"}, {"type": "block"}]
    elif mapmodes[0] == 2:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "player"}, {"type": "block"},
        {"type": "block"}, {"type": "bad", "nbt": ["blaster", "left", 2500, 6, True]}, {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "bad", "nbt": ["blaster", "left", 2500, 6, True]}, {"type": "money"}, {"type": "air"}, {"type": "air"}, {"type": "money+"}, {"type": "block"},
        {"type": "block"}, {"type": "bad", "nbt": ["blaster", "left", 2500, 6, True]}, {"type": "money"}, {"type": "money"}, {"type": "money"}, {"type": "money"}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["fish", "right", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "bad", "nbt": ["shears", "up", 50, 6, True]}, {"type": "block"}]
    elif mapmodes[0] == 3:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "money"}, {"type": "money"}, {"type": "player"}, {"type": "money"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "bad", "nbt": ["blaster", "right", 2500, 6, True]}, {"type": "money"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "bad", "nbt": ["blaster", "right", 2500, 6, True]}, {"type": "money"}, {"type": "money+"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["fish", "right", 2500, 6, True]}, {"type": "block"},  {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "bad", "nbt": ["shears", "up", 50, 6, True]}, {"type": "block"}, {"type": "block"}]
    if mapmodes[0] == 4:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "player"}, {"type": "bad", "nbt": ["shearsmoved", "up", 0, 6, True]}, {"type": "bad", "nbt": ["blockshearsmoved", "up", 0, 6, True]}, {"type": "bad", "nbt": ["shearsmoved", "up", 0, 6, True]}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "money"}, {"type": "air"}, {"type": "bad", "nbt": ["shearsmoved", "left", 0, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money+"}, {"type": "money+"}, {"type": "money"}, {"type": "air"}, {"type": "bad", "nbt": ["shearsmoved", "left", 0, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["shearsmoved", "left", 0, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "block"}, {"type": "block"}, {"type": "block"}]
    elif mapmodes[0] == 5:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "player"}, {"type": "block"}, {"type": "bad", "nbt": ["fish", "up", 2500, 6, True]}, {"type": "bad", "nbt": ["blaster", "up", 2500, 6, True]}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["blaster", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money+"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["blaster", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "money"}, {"type": "money+"}, {"type": "money"}, {"type": "bad", "nbt": ["fish", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "block"}, {"type": "block"}, {"type": "block"}]
    elif mapmodes[0] == 6:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "player"}, {"type": "bad", "nbt": ["shears", "up", 2500, 6, True]}, {"type": "air"}, {"type": "bad", "nbt": ["fish", "up", 2500, 6, True]}, {"type": "bad", "nbt": ["shears", "up", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money+"}, {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["shears", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money+"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["shears", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "money"}, {"type": "money+"}, {"type": "money"}, {"type": "bad", "nbt": ["fish", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "block"}, {"type": "block"}, {"type": "block"}]
    elif mapmodes[0] == 7:
        map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "player"}, {"type": "bad", "nbt": ["shears", "up", 2500, 6, True]}, {"type": "air"}, {"type": "bad", "nbt": ["fish", "up", 2500, 6, True]}, {"type": "bad", "nbt": ["shears", "up", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "money"}, {"type": "air"}, {"type": "money+"}, {"type": "air"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "air"}, {"type": "money"}, {"type": "bad", "nbt": ["shears", "left", 2500, 6, True]}, {"type": "bad", "nbt": ["shears", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["bat", "left", 140, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "end"}, {"type": "block"}, {"type": "block"}, {"type": "block"}]
'''
map2 = [{"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "block"},
        {"type": "block"}, {"type": "player"}, {"type": "bad", "nbt": ["shears", "up", 2500, 6, True]}, {"type": "bad", "nbt": ["fish", "up", 2500, 6, True]}, {"type": "bad", "nbt": ["shears", "up", 2500, 6, True]}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["shears", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["shears", "left", 2500, 6, True]}, {"type": "block"},
        {"type": "block"}, {"type": "air"}, {"type": "air"}, {"type": "air"}, {"type": "bad", "nbt": ["fish", "left", 2500, 6, True]}, {"type": "air"}, {"type": "block"},
        {"type": "block"}, {"type": "block"}, {"type": "block"}, {"type": "air"}, {"type": "block"}, {"type": "block"}, {"type": "block"}]
'''


#bats(1 block = 28 range)
mouse = turtle.Turtle()
mouse.ht()
mouse.up()
def mouser(x, y):
    
    global playerstats
    global moving
    global mbalance
    global antimove
    global shieldcooldown
    global ends
    global buttons
    if ends == False:
        mouse.goto(x, y)
        xp, yp = player.position()
        xm, ym = mouse.position()
        
        
        
        
        if xp < xm and xp + 50 > xm and yp + playerstats["dy"] > ym and yp - playerstats["dy"] < ym:
            if moving == {"x": 0, "y": 0} and antimove == False:
                moving = {"x": 1, "y": 0}
            elif antimove == True:
                moving = {"x": 1, "y": 0}
        if xp > xm and xp - 50 < xm and yp + playerstats["dy"] > ym and yp - playerstats["dy"] < ym:
            if moving == {"x": 0, "y": 0} and antimove == False:
                moving = {"x": -1, "y": 0}
            elif antimove == True:
                moving = {"x": -1, "y": 0}
        if yp < ym and yp + 50 > ym and xp + playerstats["dx"] > xm and xp - playerstats["dx"] < xm:
            if moving == {"x": 0, "y": 0} and antimove == False:
                moving = {"x": 0, "y": 1}
            elif antimove == True:
                moving = {"x": 0, "y": 1}
        if yp > ym and yp - 50 < ym  and xp + playerstats["dx"] > xm and xp - playerstats["dx"] < xm:
            if moving == {"x": 0, "y": 0} and antimove == False:
                moving = {"x": 0, "y": -1}
            elif antimove == True:
                moving = {"x": 0, "y": -1}
        buttonsnum = 0
        for i in buttons:
            if xm >= buttons[buttonsnum]["x"] - buttons[buttonsnum]["dx"] and ym >= buttons[buttonsnum]["y"] - buttons[buttonsnum]["dy"]and xm <= buttons[buttonsnum]["x"] + buttons[buttonsnum]["dx"] and ym <= buttons[buttonsnum]["y"] + buttons[buttonsnum]["dy"]:
                if buttons[buttonsnum]["action"] == "player_movingup()":
                    player_movingup()
                if buttons[buttonsnum]["action"] == "player_movingleft()":
                    player_movingleft()
                if buttons[buttonsnum]["action"] == "player_movingright()":
                    player_movingright()
                if buttons[buttonsnum]["action"] == "player_movingdown()":
                    player_movingdown()
                if buttons[buttonsnum]["action"] == "shield()":
                    shield()
                if buttons[buttonsnum]["action"] == "timesstop()":
                    timesstop()
            buttonsnum += 1
mph4 = 7
def generate():
    global map2
    mp = 0
    global mph4
    for i in range(1):

        for h in range(len(map2)):
            
            mpn = mp + 1
            if map2[mp]["type"] == "block":
                create_object((mp % mph4 * 20 ),(mp // mph4 * 20) , "block", "left", 500, 0, False)
            if map2[mp]["type"] == "money":
                create_object((mp % mph4 * 20 ),(mp // mph4 * 20) , "air", "left", 500, 0, False)
            if map2[mp]["type"] == "money+":
                create_object((mp % mph4 * 20 ),(mp // mph4 * 20) , "money", "left", 500, 0, False)
            if map2[mp]["type"] == "star":
                create_object((mp % mph4 * 20 ),(mp // mph4 * 20) , "star", "left", 500, 0, False)
            if map2[mp]["type"] == "player":
                player.goto((mp % mph4 * 20 ),(mp // mph4 * 20))
                playerstats["tx"], playerstats["ty"] = player.pos()
            if map2[mp]["type"] == "end":
                end.goto((mp % mph4 * 20 ),(mp // mph4 * 20))
            if map2[mp]["type"] == "bad":
                create_object((mp % mph4 * 20 ),(mp // mph4 * 20), map2[mp]["nbt"][0], map2[mp]["nbt"][1], map2[mp]["nbt"][2], map2[mp]["nbt"][3], map2[mp]["nbt"][4])
            mp += 1
player_pos.append({"x": (playerstats["x"] + moving["x"]), "y": (playerstats["y"] + moving["y"])})  
generate()
turtle.tracer(len(objects) , len(objects) )
shields = 0
shieldcooldown = 0
timestopcooldown = 0
def shield():
    global shields
    global mbalance
    global shieldcooldown
    if mbalance >= 30:
        shields += 3
        mbalance = int(mbalance) - 30
        shieldcooldown = 10000
def timesstop():
    global timestop
    global mbalance
    global timestopcooldown
    if mbalance >= 300:
        timestop += 1
        mbalance = int(mbalance) - 300
        timestopcooldown = 10000
actions = [{"w": "player_movingup()", "a": "player_movingleft()", "d": "player_movingright()", "s": "player_movingdown()", "h": "shield()", "t": "timesstop()"}]

buttons = [{"x": 0, "y": -80, "dx": 9, "dy": 9, "color": "gold", "name": "w", "action": actions[0]["w"], "turtle": ""}, {"x": 0, "y": -100, "dx": 9, "dy": 9, "color": "gold", "name": "s", "action": actions[0]["s"], "turtle": ""}, {"x": 20, "y": -100, "dx": 9, "dy": 9, "color": "gold", "name": "d", "action": actions[0]["d"], "turtle": ""}, {"x": -20, "y": -100, "dx": 9, "dy": 9, "color": "gold", "name": "a", "action": actions[0]["a"], "turtle": ""}, {"x": -60, "y": -140, "dx": 27, "dy": 9, "color": "blue", "name": "shield", "action": actions[0]["h"], "turtle": ""}, {"x": -60, "y": -180, "dx": 36, "dy": 9, "color": "blue", "name": "time.stop", "action": actions[0]["t"], "turtle": ""}]
shieldinfo = True
def buttonsc():
    global buttons
    global shieldcooldown
    global shieldinfo
    global shields
    global timestopcooldown
    buttonnum = 0
    for i in buttons:
        if buttons[buttonnum]["turtle"] == "":
            buttons[buttonnum]["turtle"] = turtle.Turtle()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].up()
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - len(buttons[buttonnum]["name"]) * 1.5, buttons[buttonnum]["y"] - 3)
            buttons[buttonnum]["turtle"].color("red")
            buttons[buttonnum]["turtle"].shape("air.gif")
            if buttons[buttonnum]["action"] == "shield()":
                buttons[buttonnum]["turtle"].shape("air.gif")
                buttons[buttonnum]["turtle"].write(buttons[buttonnum]["name"]+", "+str(shieldcooldown))
            else:
                buttons[buttonnum]["turtle"].shape("air.gif")
                buttons[buttonnum]["turtle"].write(buttons[buttonnum]["name"])
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - buttons[buttonnum]["dx"], buttons[buttonnum]["y"] - buttons[buttonnum]["dy"])
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].color(buttons[buttonnum]["color"])
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].down()
            for j in range(2):
                buttons[buttonnum]["turtle"].fd(buttons[buttonnum]["dx"] * 2)
                buttons[buttonnum]["turtle"].shape("air.gif")
                buttons[buttonnum]["turtle"].lt(90)
                buttons[buttonnum]["turtle"].fd(buttons[buttonnum]["dy"] * 2)
                buttons[buttonnum]["turtle"].lt(90)
            buttons[buttonnum]["turtle"].up()
            buttons[buttonnum]["turtle"].ht()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"], buttons[buttonnum]["y"])
        buttons[buttonnum]["turtle"].shape("air.gif")
        if buttons[buttonnum]["action"] == "shield()" and shieldinfo == True:
            if buttons[buttonnum]["turtle"] == "":
                buttons[buttonnum]["turtle"] = turtle.Turtle()
                buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].reset()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].speed(0)
            buttons[buttonnum]["turtle"].up()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - len(buttons[buttonnum]["name"]) * 1.5, buttons[buttonnum]["y"] - 3)
            buttons[buttonnum]["turtle"].color("red")
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].write(buttons[buttonnum]["name"])
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - len(buttons[buttonnum]["name"]) * 5, buttons[buttonnum]["y"] - 28)
            string = "t:", shieldcooldown, "l", shields
            buttons[buttonnum]["turtle"].write(string)
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - buttons[buttonnum]["dx"], buttons[buttonnum]["y"] - buttons[buttonnum]["dy"])
            buttons[buttonnum]["turtle"].color(buttons[buttonnum]["color"])
            buttons[buttonnum]["turtle"].down()
            for j in range(2):
                buttons[buttonnum]["turtle"].fd(buttons[buttonnum]["dx"] * 2)
                buttons[buttonnum]["turtle"].lt(90)
                buttons[buttonnum]["turtle"].shape("air.gif")
                buttons[buttonnum]["turtle"].fd(buttons[buttonnum]["dy"] * 2)
                buttons[buttonnum]["turtle"].lt(90)
            buttons[buttonnum]["turtle"].up()
            buttons[buttonnum]["turtle"].ht()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"], buttons[buttonnum]["y"])
        if buttons[buttonnum]["action"] == "timesstop()" and shieldinfo == True:
            if buttons[buttonnum]["turtle"] == "":
                buttons[buttonnum]["turtle"] = turtle.Turtle()
                buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].reset()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].speed(0)
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].up()
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - len(buttons[buttonnum]["name"]) * 1.5, buttons[buttonnum]["y"] - 3)
            buttons[buttonnum]["turtle"].color("red")
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].write(buttons[buttonnum]["name"])
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - len(buttons[buttonnum]["name"]) * 5, buttons[buttonnum]["y"] - 28)
            string = "t:", timestopcooldown
            buttons[buttonnum]["turtle"].write(string)
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"] - buttons[buttonnum]["dx"], buttons[buttonnum]["y"] - buttons[buttonnum]["dy"])
            buttons[buttonnum]["turtle"].color(buttons[buttonnum]["color"])
            buttons[buttonnum]["turtle"].down()
            for j in range(2):
                buttons[buttonnum]["turtle"].fd(buttons[buttonnum]["dx"] * 2)
                buttons[buttonnum]["turtle"].lt(90)
                buttons[buttonnum]["turtle"].shape("air.gif")
                buttons[buttonnum]["turtle"].fd(buttons[buttonnum]["dy"] * 2)
                buttons[buttonnum]["turtle"].lt(90)
            buttons[buttonnum]["turtle"].up()
            buttons[buttonnum]["turtle"].shape("air.gif")
            buttons[buttonnum]["turtle"].ht()
            buttons[buttonnum]["turtle"].goto(buttons[buttonnum]["x"], buttons[buttonnum]["y"])
            
        buttonnum += 1
    shieldinfo = False
buttonsc()
window.onclick(mouser)
window.listen()
n = 0
playsoundrun = 0
def shieldsinfo():
    global shieldinfo
    shieldinfo = True
window.onkey(shieldsinfo, "h")
window.listen()
timerev = False
if mapmodesx == 10:
    timerev = True
timestop = False
cntbgcol = 1000
block()
blockblaster()
blockshearsmoved()
air()
        
bats()
        
shears()
        
blaster()
        
fish()
        
        
shearsmoved()
star()
        
        
chainsaw()
def testobject(object, num):
                
                cntnumd = ""
                for i in range(len(str(object))):
                    if object[i] in num:
                        cntnumd += object[i]
                cntnumdfloat = ""
                for i in range(len(str(object))):
                    if object[i] in ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "."]:
                        cntnumdfloat += object[i]
                if object == "False" or object == "True":
                    if cntnumd == "" and cntnumdfloat == "":
                        if object == "False":
                            object = False
                        elif object == "True":
                            object = True
                
                elif cntnumd == str(object) and str(object) != "":
                    object = int(object)
                elif cntnumdfloat == str(object) and str(object) != "":
                    object = float(object)
                return object

turtle.up()
turtle.goto(-100, -120)
turtle.write(str(mbalance) + "$")
while True:
    end.color("red", "purple")
    if timestop == 0 and timerev == True:
        if cntbgcol >= 10 and timerev == True:
            turtle.bgcolor("white")
            cntbgcol = 0
    if timestop == 0:
        block()
        blockblaster()
        blockshearsmoved()
        
        
        bats()
        
        shears()
        
        blaster()
        
        fish()
        
        
        shearsmoved()
        
        
        
        
        chainsaw()
        
        if cntbgcol >= 10 and timerev == False:
            turtle.bgcolor("black")
            cntbgcol = 0
    else:
        if cntbgcol >= 10:
            turtle.bgcolor("gray")
            cntbgcol = 0
    if cntbgcol >= 9:
        turtle.up()
        turtle.shape("air.gif")
        turtle.reset()
        turtle.shape("air.gif")
        turtle.up()
        turtle.up()
        turtle.ht()
        turtle.color("blue")
        turtle.goto(-100, -120)
        turtle.write(str(mbalance) + "$")
        shieldsinfo()
    testbad()
    testtruebad()
    testbad()
    testtruebad()
    testbad()
    testtruebad()
    testtruebad()
    buttonsc()
    testbad()
    air()
    star()
    testbad()
    buttonsc()
    moneyclaim()
    buttonsc()
    testtruebad()
    testtruebad()
    testbad()
    testbad()
    turtle.ht()
    moves = "None"
    window.listen()
    playerstats["x"], playerstats["y"] = player.position()
    if player.isvisible():
        player.goto(playerstats["x"] + moving["x"], playerstats["y"] + moving["y"])
        player_pos.append({"x": (playerstats["x"] + moving["x"]), "y": (playerstats["y"] + moving["y"])})
    playerstats["x"], playerstats["y"] = player.position()
    
    testbad()
    window.listen()
    playerstats["x"], playerstats["y"] = player.position()
    if player.isvisible():
        player.goto(playerstats["x"] + moving["x"], playerstats["y"] + moving["y"])
    playerstats["x"], playerstats["y"] = player.position()
    end.color("purple", "red")
    testbad()
    window.listen()
    playerstats["x"], playerstats["y"] = player.position()
    if player.isvisible():
        player.goto(playerstats["x"] + moving["x"], playerstats["y"] + moving["y"])
    playerstats["x"], playerstats["y"] = player.position()
    testbad()
    window.listen()
    playerstats["x"], playerstats["y"] = player.position()
    if player.isvisible():
        player.goto(playerstats["x"] + moving["x"], playerstats["y"] + moving["y"])
    playerstats["x"], playerstats["y"] = player.position()
    testbad()
    window.listen()
    playerstats["x"], playerstats["y"] = player.position()
    if player.isvisible():
        player.goto(playerstats["x"] + moving["x"], playerstats["y"] + moving["y"])
    playerstats["x"], playerstats["y"] = player.position()
    player.speed(0)
    cntbgcol += 1
    sudo = open("console.txt", "r", encoding="utf-8")
    sudo = sudo.read()
    
    data = {"playerstats": playerstats, "objects": objects, "ids": ids, "mbalance": mbalance, "moving": moving, "buttons": buttons, "actions": actions, "player_pos": player_pos, "tick": tick, "tick_pos": tick_pos, "map2": map2}
    
    if "$sudo hack time.off/$" in sudo:
        timestop = 1
        timestopcooldown = 1000000000
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack time.on/$" in sudo:
        timestop = 0
        timestopcooldown = 0
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack shield.on/$" in sudo:
        shields = 10
        shieldcooldown = 1000000000
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack shield.off/$" in sudo:
        shields = 0
        shieldcooldown = 0
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack god.on/$" in sudo:
        godmode = True
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack god.off/$" in sudo:
        godmode = False
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack antimove.on/$" in sudo:
        antimove = True
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack antimove.off/$" in sudo:
        antimove = False
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack teleport.on/$" in sudo:
        teleport = True
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack teleport.off/$" in sudo:
        teleport = False
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack spectator.on/$" in sudo:
        spectator = True
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack spectator.off/$" in sudo:
        spectator = False
        sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack getdata/" in sudo:
        get = sudo.split("$")
        for getfile in range(len(get)):
            if "sudo hack getdata/" in get[getfile]:
                sudoget = get[getfile].split("/")
                print(data[sudoget[1]])
                sudoreset = open("console.txt", "w", encoding="utf-8")
    if "$sudo hack setdata/" in sudo:
        cmd = sudo.split("$")
        for kl in range(len(cmd)):
            if "sudo hack setdata" in cmd[kl]:
                sudocmd = cmd[kl].split("/")
                if sudocmd[-2] == ".0.":
                    if sudocmd[1] == "int":


                        data[sudocmd[3]] = int(sudocmd[2])
                    elif sudocmd[1] == "str":


                        data[sudocmd[3]] = str(sudocmd[2])
                    elif sudocmd[1] == "float":


                        data[sudocmd[3]] = float(sudocmd[2])
                    elif sudocmd[1] == "bool":


                        data[sudocmd[3]] = bool(sudocmd[2])
                elif sudocmd[-2] == ".1.":
                    if sudocmd[1] == ".":
                        sudocmd[4] = testobject(sudocmd[4], nums)

                        


                        

                        
                        data[sudocmd[3]] = sudocmd[4]
                elif sudocmd[-2] == ".2.":
                    if sudocmd[1] == ".":
                        sudocmd[4] = testobject(sudocmd[4], nums)
                        sudocmd[5] = testobject(sudocmd[5], nums)

                        


                        

                        
                        data[sudocmd[3]][sudocmd[4]] = sudocmd[5]
                elif sudocmd[-2] == ".3.":
                    if sudocmd[1] == ".":

                        sudocmd[4] = testobject(sudocmd[4], nums)
                        sudocmd[5] = testobject(sudocmd[5], nums)
                        sudocmd[6] = testobject(sudocmd[6], nums)


                        


                        

                        data[sudocmd[3]][sudocmd[4]][sudocmd[5]] = sudocmd[6]
        sudoreset = open("console.txt", "w", encoding="utf-8")
    playerstats = data["playerstats"]
    objects = data["objects"]
    ids = data["ids"]
    mbalance = data["mbalance"]
    moving = data["moving"]
    buttons = data["buttons"]
    actions = data["actions"]
    player_pos = data["player_pos"]
    tick = data["tick"]
    tick_pos = data["tick_pos"]
    map2 = data["map2"]